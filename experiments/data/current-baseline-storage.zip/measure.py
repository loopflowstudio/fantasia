"""Offline re-encoding of retained trusted evidence; never admitted for resume."""
from dataclasses import replace
import gzip
import io
import json
from pathlib import Path
import shutil
import time

import torch

from manabot.arena.models import canonical_sha256, file_sha256
from manabot.training.models import StageRecord, TrainingRun
from manabot.training.recovery import DiagnosticPrefix, UpdateSnapshot, load_update
from manabot.verify.store import VerifyStore


def encoded_bytes(state: UpdateSnapshot) -> int:
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode="wb", mtime=0) as stream:
        torch.save(state, stream)
    return buffer.tell()


def main() -> None:
    start = time.monotonic()
    root = Path('.runs/etu118-calibration-2')
    path = root / 'training/attempt-0000/run.json'
    run = TrainingRun.model_validate_json(path.read_text())
    with VerifyStore(root / 'experiment.sqlite') as store:
        state = load_update(run, store)
    records = [*state.completed_stages, state.record]
    compact_records = [StageRecord.model_validate(row.model_dump(exclude={'diagnostics'})) for row in records]
    compact = replace(state, format_version=3, completed_stages=compact_records[:-1], record=compact_records[-1], diagnostic_run_id=run.id, diagnostic_prefixes=tuple(DiagnosticPrefix(row.id, len(row.diagnostics), canonical_sha256(row.diagnostics)) for row in records))
    compact_bytes = encoded_bytes(compact)
    # Same buffers/weights; isolate serialization growth from diagnostic history.
    long_prefix = replace(compact, diagnostic_prefixes=tuple(replace(prefix, count=12800) for prefix in compact.diagnostic_prefixes))
    updates = 12800
    projection = int(3 * ((updates // 128 + 30) * (compact_bytes + 1024**2) + 4 * path.stat().st_size * updates / 32) + 2 * 1024**3)
    assert run.recovery_artifact is not None
    result = dict(source_run_sha256=file_sha256(path), source_snapshot=run.recovery_artifact, original_format=state.format_version, original_reencoded_bytes=encoded_bytes(state), compact_reencoded_bytes=compact_bytes, compact_12800_count_bytes=encoded_bytes(long_prefix), run_json_bytes=path.stat().st_size, provisional_updates_per_seed=updates, seeds=3, projected_bytes=projection, reserve_bytes=4*1024**3, free_bytes=shutil.disk_usage('.').free, prior_preparation_seconds=2788.716979166954, measurement_seconds=time.monotonic()-start, limitation='Offline format measurement on retained 32-update state; count-only size stress is not training or complete calibration. Frozen originals unchanged.')
    Path('.runs/etu118-snapshot-storage/result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
