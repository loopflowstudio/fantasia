"""Calibrate, freeze, and start the bounded ETU-105 mini filter-scope screen."""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import socket
import time

from manabot.arena.models import canonical_sha256
from manabot.infra.hypers import AgentSpec
from manabot.training.checkpoint_queue import MonitoringBudget
from manabot.training.execution import atomic_json
from manabot.training.experiment_execution import ExperimentSchedule, Hardware, HardwareInventory
from manabot.training.experiment_runner import run_experiment
from manabot.training.experiments import Baseline, Case, Experiment, LearningRule, Model
from manabot.training.models import AtaraxosMoveLearning, TrainingRegime, TrainingRun, TrainSelfPlay
from manabot.training.monitor_evaluation import MonitorProtocol
from manabot.training.presets import ataraxos_mtg_v1


TASK = "ETU-105"
ROOT = Path("/Users/jack/src/etude")
OUT = ROOT / ".runs/etu105-mini-filter-scope-20261006-3-calibration-continuation"
SOURCE = ROOT / ".runs/etu105-mini-filter-scope-20261006-1-source"
SOURCE_COMMIT = "a108ed3428a7f8c363a28c7df5dc71a4cd8d2719"
ORIGINAL_STARTED_UNIX = 1791328721.724962
ORIGINAL_DEADLINE_UNIX = 1791415121.724962
CALIBRATION_SEED = 10500
SEEDS = (10501, 10502, 10503)
ORDER = ((0, 1), (1, 0), (0, 1))
CALIBRATION_DEALS = (1_910_105_000,)
MONITORING_DEALS = tuple(range(1_910_105_100, 1_910_105_125))
FINAL_DEALS = tuple(range(9_305_000, 9_305_025))
RANDOM_DIAGNOSTIC_DEALS = tuple(range(9_205_000, 9_205_025))


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _regime(updates: int, run_seconds: float) -> TrainingRegime:
    regime = ataraxos_mtg_v1().regime()
    regime.id = "actor-critic"
    regime.agent = AgentSpec.model_validate(
        {
            **regime.agent.model_dump(mode="json"),
            "value_kind": "scalar",
            "value_aggregation": "masked_mean",
        }
    )
    regime.wall_seconds = run_seconds
    per_stage = updates // 2
    for index, stage in enumerate(regime.stages):
        if not isinstance(stage, TrainSelfPlay):
            raise TypeError("ETU-105 filter scope requires self-play stages")
        stage.updates = per_stage
        stage.execution.wall_seconds = run_seconds / 2 - 10
        stage.execution.memory_bytes = 15 * 1024**3
        stage.id = f"policy-{index}"
        stage.initial = f"policy-{index - 1}" if index else None
    return regime


def _experiment(updates: int, run_seconds: float, schedule: ExperimentSchedule) -> Experiment:
    control = _regime(updates, run_seconds)
    stage = control.stages[0]
    assert isinstance(stage, TrainSelfPlay)
    rule = stage.learning.model_copy(deep=True)
    assert isinstance(rule, AtaraxosMoveLearning)
    rule.filter_scope = "actor"
    return Experiment(
        name="",
        baseline=Baseline.capture("masked-mean-scalar-filter-base", control),
        cases=(
            Case("actor-critic", label="filter actor and critic"),
            Case("actor", (LearningRule(rule),), label="filter actor only"),
        ),
        schedule=schedule,
    )


def _hardware() -> HardwareInventory:
    return HardwareInventory(
        resources=(
            Hardware(
                name="mini-local-cpu",
                host=socket.gethostname(),
                cpu_threads=max(2, os.cpu_count() or 2),
            ),
        )
    )


def _schedule(
    *,
    seeds: tuple[int, ...],
    order: tuple[tuple[int, ...], ...],
    wall_seconds: float,
    process_seconds: float,
    monitoring_seconds: float,
    attempt_seconds: float,
    deals: tuple[int, ...],
    checkpoint_seconds: float,
) -> ExperimentSchedule:
    return ExperimentSchedule(
        seeds=seeds,
        hardware="mini-local-cpu",
        wall_seconds=wall_seconds,
        process_seconds=process_seconds,
        monitoring=MonitoringBudget(
            seconds=monitoring_seconds,
            attempt_seconds=attempt_seconds,
            protocol=MonitorProtocol(
                deal_seeds=deals,
                bootstrap_seed=105,
                bootstrap_replicates=2000,
                game_seconds=120,
                max_commands=10_000,
            ),
        ),
        checkpoint_seconds=checkpoint_seconds,
        scientific_deal_seeds=FINAL_DEALS + RANDOM_DIAGNOSTIC_DEALS,
        order=order,
        disk_reserve_bytes=4 * 1024**3,
    )


def _training_runs(directory: Path) -> list[TrainingRun]:
    return [
        TrainingRun.model_validate_json(path.read_text())
        for path in sorted((directory / "training").glob("attempt-*/run.json"))
    ]


def main() -> None:
    started = time.time()
    if started >= ORIGINAL_DEADLINE_UNIX:
        raise TimeoutError("original ETU-105 24-hour wall budget is exhausted")
    OUT.mkdir(parents=True, exist_ok=False)
    atomic_json(
        OUT / "preflight.json",
        {
            "task": TASK,
            "started_unix": started,
            "original_started_unix": ORIGINAL_STARTED_UNIX,
            "deadline_unix": ORIGINAL_DEADLINE_UNIX,
            "continuation": "named calibration continuation; no scientific counts were frozen",
            "retained_attempts": [
                str(ROOT / ".runs/etu105-mini-filter-scope-20261006-1-failed-start-1"),
                str(ROOT / ".runs/etu105-mini-filter-scope-20261006-1"),
                str(ROOT / ".runs/etu105-mini-filter-scope-20261006-2"),
            ],
            "source_commit": SOURCE_COMMIT,
            "source_export": str(SOURCE),
            "execution_patch_sha256": _sha(SOURCE / "manabot/training/execution.py"),
            "runner_patch_sha256": _sha(SOURCE / "manabot/training/experiment_runner.py"),
            "queue_patch_sha256": _sha(SOURCE / "manabot/training/checkpoint_queue.py"),
            "supervisor_sha256": _sha(Path(__file__)),
            "supervisor_pid": os.getpid(),
            "prior_study": str(ROOT / ".runs/etu103-mini-depth-20261006-1"),
            "prior_status": "completed",
            "prior_supervisor_pid": 78829,
            "prior_pid_liveness": "not-live",
            "contrast": "actor-only versus actor-and-critic advantage filtering",
            "common_base": "masked_mean scalar, ataraxos-mtg-v1 otherwise fixed",
            "hardware": "Apple M1 with 16 GiB physical memory; recipes capped at 15 GiB",
            "clocks": {
                "allocation": "wall from supervisor start; additive learner/evaluator process time",
                "training": "TrainingRun cumulative wall seconds",
                "milestones": "initialization plus stage endpoints; periodic exports approximately hourly",
            },
            "endpoints": {
                "monitoring": list(MONITORING_DEALS),
                "random_diagnostic": list(RANDOM_DIAGNOSTIC_DEALS),
                "untouched_final": list(FINAL_DEALS),
            },
            "stopping": [
                "nonfinite loss, illegal action, replay failure, process/wall deadline, or disk reserve",
                "retain partial attempts; never replace a failed seed",
                "flat monitoring prompts review and never stops for efficacy",
                "checkpoint-safe interruption only; no automatic efficacy stop",
            ],
            "strength_inspected_before_counts": False,
            "sync_failure": "lf sync failed before mutation: Operation not permitted on read-only git metadata",
        },
    )

    calibration_schedule = _schedule(
        seeds=(CALIBRATION_SEED,),
        order=((0, 1),),
        wall_seconds=2400,
        process_seconds=2400,
        monitoring_seconds=900,
        attempt_seconds=150,
        deals=CALIBRATION_DEALS,
        checkpoint_seconds=10_000,
    )
    calibration = _experiment(40, 600, calibration_schedule)
    atomic_json(OUT / "calibration-intent.json", calibration.resolve().receipt())
    calibration_result = run_experiment(
        calibration, _hardware(), OUT / "calibration"
    )
    if calibration_result.status != "completed":
        raise RuntimeError("calibration did not complete; scientific counts remain unfrozen")

    runs = _training_runs(OUT / "calibration")
    if len(runs) != 2 or any(run.status != "completed" for run in runs):
        raise RuntimeError("calibration lacks both completed arms")
    seconds_per_update = max(run.seconds / run.updates_through() for run in runs)
    setup_seconds = max(run.setup_seconds for run in runs)
    monitor_files = sorted((OUT / "calibration/monitoring").glob("attempt-*/evaluation/monitor.json"))
    monitors = [json.loads(path.read_text()) for path in monitor_files]
    complete_monitors = [m for m in monitors if m.get("error") is None and len(m.get("rows", [])) == 4]
    if not complete_monitors:
        raise RuntimeError("calibration produced no complete four-game monitoring block")
    seconds_per_block = max(float(m["evaluation_seconds"]) for m in complete_monitors)

    # Six paired runs target two hours each. Freeze a common even update count
    # from the slower arm with 20% headroom, before reading any score field.
    target_run_seconds = 7200
    updates = int((target_run_seconds - setup_seconds) / (1.2 * seconds_per_update))
    updates = max(40, (updates // 20) * 20)
    predicted_run_seconds = setup_seconds + updates * seconds_per_update
    expected_checkpoints = 18  # initialization + two roughly-hourly stage endpoints.
    games_per_deal = 4
    monitoring_games_per_milestone = len(MONITORING_DEALS) * games_per_deal
    if monitoring_games_per_milestone != 100:
        raise RuntimeError("live milestone protocol must reserve exactly 100 games")
    block_multiplier = len(MONITORING_DEALS) / len(CALIBRATION_DEALS)
    predicted_monitor_seconds = 1.25 * expected_checkpoints * block_multiplier * seconds_per_block
    random_scoring_seconds = 1.25 * len(RANDOM_DIAGNOSTIC_DEALS) * seconds_per_block
    final_scoring_seconds = 1.25 * len(FINAL_DEALS) * seconds_per_block
    scoring_reserve = random_scoring_seconds + final_scoring_seconds
    remaining = ORIGINAL_DEADLINE_UNIX - time.time() - 600
    learning_allowance = 6 * target_run_seconds
    monitor_allowance = min(
        remaining - learning_allowance - scoring_reserve,
        max(predicted_monitor_seconds, expected_checkpoints * 600),
    )
    required_monitor_seconds = expected_checkpoints * block_multiplier * seconds_per_block
    if monitor_allowance < required_monitor_seconds:
        raise RuntimeError("calibration cannot admit all seeds and 100-game milestones within 24 hours")
    attempt_seconds = min(1200.0, monitor_allowance / expected_checkpoints)
    if attempt_seconds < seconds_per_block * block_multiplier:
        raise RuntimeError("per-milestone evaluation allowance is infeasible")

    science_schedule = _schedule(
        seeds=SEEDS,
        order=ORDER,
        wall_seconds=remaining,
        process_seconds=learning_allowance + monitor_allowance,
        monitoring_seconds=monitor_allowance,
        attempt_seconds=attempt_seconds,
        deals=MONITORING_DEALS,
        checkpoint_seconds=3600,
    )
    science = _experiment(updates, target_run_seconds, science_schedule)
    resolved = science.resolve()
    atomic_json(
        OUT / "frozen-plan.json",
        {
            "task": TASK,
            "frozen_unix": time.time(),
            "source_commit": SOURCE_COMMIT,
            "experiment": resolved.receipt(),
            "schedule": science_schedule.model_dump(mode="json"),
            "calibration": {
                "run_ids": [run.id for run in runs],
                "run_seconds": [run.seconds for run in runs],
                "updates": [run.updates_through() for run in runs],
                "seconds_per_update_upper": seconds_per_update,
                "setup_seconds_upper": setup_seconds,
                "evaluation_seconds_per_four_games_upper": seconds_per_block,
            },
            "admission": {
                "updates_per_run": updates,
                "predicted_run_seconds": predicted_run_seconds,
                "predicted_monitor_seconds_with_margin": predicted_monitor_seconds,
                "monitoring_games_per_milestone": monitoring_games_per_milestone,
                "monitoring_deals_per_milestone": len(MONITORING_DEALS),
                "random_scoring_seconds_reserved": random_scoring_seconds,
                "final_scoring_seconds_reserved": final_scoring_seconds,
                "original_deadline_unix": ORIGINAL_DEADLINE_UNIX,
                "seeds": list(SEEDS),
                "order": [list(row) for row in ORDER],
                "strength_inspected": False,
                "no_post_score_seed_reduction": True,
            },
            "random_diagnostic": {
                "status": "separately reserved; schedule after training without touching final deals",
                "deal_seeds": list(RANDOM_DIAGNOSTIC_DEALS),
            },
            "untouched_final": {
                "status": "reserved and not consumed by live monitoring",
                "deal_seeds": list(FINAL_DEALS),
            },
        },
    )
    result = run_experiment(science, _hardware(), OUT / "science")
    atomic_json(
        OUT / "supervisor-result.json",
        {
            "task": TASK,
            "status": result.status,
            "experiment_id": result.id,
            "finished_unix": time.time(),
            "elapsed_seconds": time.time() - started,
            "notebook": result.notebook,
            "dashboard": str(OUT / "science/comparison.html"),
            "random_diagnostic_status": "pending separate bounded diagnostic",
            "final_deals_status": "untouched",
        },
    )


if __name__ == "__main__":
    main()
